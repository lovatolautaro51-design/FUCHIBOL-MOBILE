# FUCHIBOL Mobile 0.7.0

Proyecto reconstruido para Android (WebView) y navegador. Incluye un partido 11 contra 11 con cámara cenital, equipos seleccionables, formaciones, controles táctiles, IA básica, arqueros, goles, marcador, reloj, pausa y reinicio.

## Ejecutar en PC
Abrí `app/src/main/assets/index.html` en un navegador moderno.

## Compilar APK
Requisitos: Android Studio/SDK 35, JDK 17 y Gradle 8.7.

Desde la raíz:
```bash
gradle assembleDebug
```
El APK de depuración queda en:
`app/build/outputs/apk/debug/app-debug.apk`

También se incluye `.github/workflows/build-apk.yml` para compilarlo en GitHub Actions. Subí el proyecto a un repositorio y ejecutá el workflow `Build FUCHIBOL Mobile APK`.

## Controles
- Joystick izquierdo: mover el jugador controlado.
- PASE: pase al compañero.
- TIRO: remate.
- CARRERA: acelerar.
- CAMBIAR: cambiar al jugador más cercano a la pelota.
- ENTRADA: intentar recuperar la pelota.
- PAUSA: pausar, reanudar o reiniciar.

## Estado honesto
Esta es una base jugable reconstruida, no una simulación comercial terminada. La IA y las reglas son simplificadas; no incluye todavía licencias oficiales, plantillas completas verificadas, online/servidores, MyClub/Master League completos, árbitro avanzado, fuera de juego, VAR, animaciones 3D ni audio de transmisión. El APK no está incluido porque todavía no se ejecutó una compilación Android en este entorno.
